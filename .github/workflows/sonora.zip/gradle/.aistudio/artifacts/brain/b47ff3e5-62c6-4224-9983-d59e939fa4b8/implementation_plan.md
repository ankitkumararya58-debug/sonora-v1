# SONORA - Minimal Music Widget Customization App

SONORA is a minimal, modern Android application that bridges active system media playback with customizable widget design, allowing users to control playback, customize album artwork, configure widget themes, and preview both compact pill and expanded modern card widgets.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following key decisions have been confirmed based on your input:
> - **Widget Presets**: Supporting **Compact Pill** and **Expanded Modern Card** presets.
> - **Android Home Screen Widget**: Including both an in-app interactive widget customizer and an actual Android **Home Screen AppWidget** (`AppWidgetProvider`) with working playback controls.
> - **Customization Controls**: **Theme** (Dark, Light, Transparent), **Corner Radius**, **Background Opacity**, and **Blur / Border** styling.
> - **Android MediaSession Integration**: Uses `NotificationListenerService` & `MediaSessionManager` with a gentle permission card linking directly to Android system settings to access real media sessions without fake data.

- **Confirmed Decision 1**: Compact pill and expanded modern card widget presets.
- **Confirmed Decision 2**: Zero-permission Android Photo Picker (`PickVisualMedia`) for custom artwork, saving chosen covers locally to internal storage.
- **Confirmed Decision 3**: Real Android Home Screen AppWidget alongside the in-app customizer.

---

## 1. Overview & Core Concept

- **What It Does**: SONORA detects active music playback on the device across apps (Spotify, YouTube Music, Apple Music, Tidal, etc.) via Android's native `MediaSessionManager`. Users can view real-time track metadata (title, artist, album art), toggle play/pause, skip tracks, replace album art with photos from their gallery, customize widget aesthetics (themes, radius, opacity, blur), and pin the widget directly to their Android Home Screen.
- **Target Audience / Persona**: Music enthusiasts and customization fans who desire sleek, distraction-free playback widgets tailored to their personal wallpaper aesthetic.
- **Key Value**: Native playback control combined with personalized artwork override and custom widget styling—without ads, telemetry, or account sign-ups.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **First Launch & Media Permission**:
   - App opens with a dark, refined interface.
   - If notification listener permission is not yet granted, an unobtrusive banner explains why it is needed and provides a one-tap button to Android's "Notification Access" settings.
   - Once granted, the active media session (e.g., from Spotify or YouTube Music) is detected immediately.
2. **Home Screen (Now Playing & Quick Controls)**:
   - High-contrast album artwork card with soft drop shadows or frosted borders.
   - Song title (fluid typography) and artist name.
   - Intuitive playback controls: Previous Track, Play/Pause toggle with animated state changes, Next Track.
   - Prominent **"Change Cover"** action button launching the native Android Photo Picker.
   - If a custom cover is active, a badge indicates "Custom Artwork Active" with an option to restore original album art.
3. **Customize Screen (Widget Studio)**:
   - Live interactive widget canvas showcasing the selected preset (**Compact Pill** or **Expanded Modern Card**) reacting in real-time to tweaks.
   - **Theme Selector**: Dark (deep obsidian `#0D0F12`), Light (crisp ceramic `#F4F5F7`), Transparent (frosted glass outline).
   - **Styling Controls**: Slider for corner radius (12dp to 36dp), slider for background opacity (10% to 100%), and frosted border / blur toggle.
   - "Apply to Home Screen Widget" instant sync button.
4. **Settings Screen**:
   - Permission status check and quick re-authorization shortcut.
   - Storage manager: view and clear saved custom cover images.
   - Step-by-step visual guide on pinning the SONORA widget to the Android Home Screen.
   - App info, privacy notice (100% on-device, zero network tracking).

### Visual Identity & Theme

- **Aesthetic Direction**: Minimal luxury dark, monochromatic precision, subtle tactile micro-interactions.
- **Color Palette**:
  - Background: `#0B0D10` (Obsidian)
  - Surface Card: `#14171D` (Carbon)
  - Surface Highlight: `#1E232B`
  - Accent / Primary: `#E6EDF3` (Crisp Silver White)
  - Accent Highlight: `#38BDF8` (Muted Electric Cyan)
  - Text Primary: `#F0F6FC`
  - Text Secondary: `#8B949E`
- **Typography & Hierarchy**: Clean modern sans-serif with bold display headings, medium subheadings, and high-legibility metadata.
- **Component Styling & Layout**: Deep rounded corners (20–28dp), tactile button ripples, seamless edge-to-edge support with proper window insets.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Native MediaSessionManager & NotificationListenerService**
  - *Chosen Approach*: Implement a lightweight `NotificationListenerService` (`SonoraMediaNotificationListener`) that enables `MediaSessionManager` to capture live media tokens from any playing media app.
  - *Why*: This is the only legitimate Android OS API to read song metadata and dispatch transport commands (play/pause/skip) to third-party music players without fake or simulated data.
  - *Fallback / Empty State*: If no music player is currently active, SONORA displays a helpful "No Active Player Detected" state with clear tips to start playback in any media app, plus a "Launch Music App" shortcut.
- **Decision 2: Zero-Permission Photo Picker for Custom Artwork**
  - *Chosen Approach*: Use `ActivityResultContracts.PickVisualMedia()` to select gallery images and stream-copy the chosen image to the app's internal private storage directory (`filesDir/custom_cover.png`).
  - *Why*: Zero runtime storage permissions required (`READ_EXTERNAL_STORAGE` is obsolete and forbidden under modern Google Play policies), completely secure and private.
- **Decision 3: Android Home Screen AppWidget via RemoteViews**
  - *Chosen Approach*: Implement `SonoraAppWidgetProvider` registered in `AndroidManifest.xml` with `RemoteViews` layouts for both compact and card modes, synchronized with playback and customization preferences.
  - *Why*: Enables users to place SONORA directly on their launcher home screen for real-time one-touch music control.
- **Decision 4: DataStore Preferences for Persistence**
  - *Chosen Approach*: Store theme, corner radius, opacity, and custom cover path in Android Jetpack DataStore / SharedPreferences.
  - *Why*: Simple, fast, thread-safe, and zero database overhead.

---

## 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────┐
│                    Android System Audio                     │
│         (Spotify / YouTube Music / Apple Music / etc.)      │
└──────────────────────────────┬──────────────────────────────┘
                               │ MediaSession Token
                               ▼
┌─────────────────────────────────────────────────────────────┐
│             SonoraMediaNotificationListener                 │
│                 & MediaSessionManager                       │
│    - Registers MediaController.Callback                     │
│    - Extracts Title, Artist, Album, Bitmaps, PlaybackState  │
│    - Sends Play/Pause/Skip transport commands               │
└──────────────────────────────┬──────────────────────────────┘
                               │ StateFlow<MediaTrackState>
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                      SonoraViewModel                        │
│    - Holds TrackState (Title, Artist, Artwork, IsPlaying)   │
│    - Holds WidgetCustomization (Theme, Radius, Opacity)     │
│    - Handles Custom Artwork pick & disk cache               │
│    - Triggers AppWidget updates                             │
└──────────────┬───────────────────────────────┬──────────────┘
               │                               │
               ▼                               ▼
┌──────────────────────────────┐ ┌─────────────────────────────┐
│      Jetpack Compose UI      │ │    SonoraAppWidgetProvider  │
│ - Home (Now Playing card)    │ │   - RemoteViews             │
│ - Customize (Widget Studio)  │ │   - Broadcast PendingIntents│
│ - Settings (Permissions/Info)│ │   - Home Screen AppWidget   │
└──────────────────────────────┘ └─────────────────────────────┘
```

### Key Components

1. **`com.example.service.SonoraMediaNotificationListener`**:
   - Inherits `NotificationListenerService`.
   - Manages active `MediaController` instances and registers callbacks for track changes, playback state toggles, and metadata updates.
2. **`com.example.data.MediaRepository` & `WidgetConfigRepository`**:
   - Exposes reactive `StateFlow` for media playback status.
   - Manages custom artwork file I/O (`custom_cover.png`) and widget customization preferences (theme, radius, opacity).
3. **`com.example.widget.SonoraAppWidgetProvider`**:
   - `AppWidgetProvider` rendering the home screen widget using `RemoteViews`.
   - Handles `ACTION_PLAY_PAUSE`, `ACTION_NEXT`, `ACTION_PREVIOUS` broadcast intents to control playback directly from the home screen.
4. **Compose UI Layers**:
   - `HomeScreen`: Now Playing card, animated playback buttons, "Change Cover" action, permission banner.
   - `CustomizeScreen`: Live interactive preview with layout preset toggles, theme chips, and dimension sliders.
   - `SettingsScreen`: Permissions status, storage cleaner, widget pinning guide.
